--Podczas wprowadzania ponizszych danych powinien uruchomi�
--si� wyzwalacz informuj�cy o tym �e rachunek nie mo�e by� ujemny:
SET client_encoding='utf-8';

INSERT INTO Rachunek(Cena) VALUES(-55);