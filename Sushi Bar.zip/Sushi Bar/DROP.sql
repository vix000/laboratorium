SET client_encoding='utf-8';

DROP TABLE Zatrudnienie_kasjera;
DROP TABLE Przyjecie_rachunku;
DROP TABLE Kasjer;
DROP TABLE Zatrudnienie_menadzera;
DROP TABLE Zlecenie;
DROP TABLE Sushi_Bar;
DROP TABLE Menadzer;
DROP TABLE Przygotowanie_zamówienia;
DROP TABLE Sushi_Master;
DROP TABLE Przyjecie_zamówienia;
DROP TABLE Złożenie_zamówienia;
DROP TABLE Co_zawiera_zamówienie;
DROP TABLE Zamówienie;
DROP TABLE Dostarczenie;
DROP TABLE Kelner;
DROP TABLE placenie;
DROP TABLE Klient;
DROP TABLE Rachunek;
DROP TABLE Zestaw_sushi;


